<!DOCTYPE html>
<html lang="es" dir="ltr">

<head>
    <meta charset="utf-8">
    <title>Perfil - Royal Dice</title>
    <link rel="stylesheet" href="<?php echo e(asset('/css/perfil.css')); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset('img/icono.png')); ?>" /> 
    
</head>

<body>
    <img src="<?php echo e(asset('img/logo.png')); ?>" id="logo">
    

    <form class="box" method="post" action="<?php echo e(route('perfil.store')); ?> ">
        <?php echo csrf_field(); ?> 
        <div class="user">
        <h3 style="text-align: left;padding-right: 30px;">USUARIO</h3>
        <h3 style="text-align: right;padding-left: 108px;">MONEDAS</h3>
        </div>
        <div class="user">
            <input type="text" disabled name="name" style="margin-right: 15px;"placeholder="Usuario" value="<?php echo e(Auth::user()->name); ?>"> 
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            
                <small>*<?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
            <input type="text" disabled name="fichas" value="<?php echo e(Auth::user()->fichas); ?>">
        </div>
        
        
        <br>
        <br>
        <h4>Cambiar Contraseña</h4>
        <br>
        <div class="repetir">
            <input type="password" name="newpassword" placeholder="Nueva Contraseña">
        </div>
        <br>
         <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            
            <small>*<?php echo e($message); ?></small>
            <br>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
        <input type="submit" name="enviar">
        

    </form>
    <a href="<?php echo e(route('main')); ?>"><button>Volver</button></a>




</body>

</html><?php /**PATH C:\xampp\htdocs\2020-21-DAW2-M12-Royal-Dice\resources\views/perfil.blade.php ENDPATH**/ ?>