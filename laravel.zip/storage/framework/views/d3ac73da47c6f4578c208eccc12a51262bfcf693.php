<!DOCTYPE html>
<html lang="es">
<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <?php echo $__env->make('layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="juego">
        <div class="row" style="color: white">
            <div class="col-4">
                <h4>Historial Blackjack</h4>
            
            <ul>
            <?php $__currentLoopData = $registros[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blackjack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><span> Apuesta: <?php echo e($blackjack->apuesta); ?>  </span> <span> Resultado: <?php echo e($blackjack->beneficioperdida); ?>  </span> </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            </div>
            <div class="col-4">
                <h4>Historial Carta Más Alta</h4>
            
            <ul>
                <?php $__currentLoopData = $registros[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartamasalta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><span> Apuesta: <?php echo e($cartamasalta->apuesta); ?>  </span> <span> Resultado: <?php echo e($cartamasalta->beneficioperdida); ?>  </span> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="col-4">
                <h4>Historial Tragaperras</h4>
            
            <ul>
                <?php $__currentLoopData = $registros[2]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tragaperras): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><span> Apuesta: <?php echo e($tragaperras->apuesta); ?>  </span> <span> Resultado: <?php echo e($tragaperras->beneficioperdida); ?>  </span> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\2020-21-DAW2-M12-Royal-Dice\resources\views/historial.blade.php ENDPATH**/ ?>