<!DOCTYPE html>
<html lang="es" dir="ltr">

<head>
    <meta charset="utf-8">
    <title>Register</title>
    <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
</head>

<body>
    <img src="<?php echo e(asset('img/logo.png')); ?>" id="logo">
    
    <form class="box registro" method="post" action="<?php echo e(route('register.store')); ?>">
        <?php echo csrf_field(); ?>
        <h3>Registro</h3>
        <input type="text" name="name" required placeholder="Usuario" value="<?php echo e(old('user')); ?>">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            
            <small>*<?php echo e($message); ?></small>
            <br>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input type="email" name="email" required placeholder="Email" value="<?php echo e(old('email')); ?>">
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            
            <small>*<?php echo e($message); ?></small>
            <br>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input type="password" name="password" required placeholder="Contraseña">
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            
            <small>*<?php echo e($message); ?></small>
            <br>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input type="submit" name="enviar">
        <p>¿Ya tienes cuenta?</p><a href="./login">Inicia sesión</a>
    </form>
</body>

</html><?php /**PATH C:\xampp\htdocs\2020-21-DAW2-M12-Royal-Dice\resources\views/register.blade.php ENDPATH**/ ?>