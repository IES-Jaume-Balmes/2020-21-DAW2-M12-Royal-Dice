<!DOCTYPE html>
<html lang="es">
<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <?php echo $__env->make('layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="juego">
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\2020-21-DAW2-M12-Royal-Dice\resources\views/template.blade.php ENDPATH**/ ?>