<!DOCTYPE html>
<html lang="es">
<head>
    @include('layouts/head')
</head>
<body>
    @include('layouts/header')
    <div class="juego">
    </div>
</body>
</html>